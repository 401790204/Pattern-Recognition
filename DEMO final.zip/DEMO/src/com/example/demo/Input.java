package com.example.demo;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Input extends Activity {

	SQLiteDatabase db;
	TextView tv;
	EditText A,B;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_input);
		
		Button but1 = (Button) findViewById(R.id.button1);  //����
		Button but2 = (Button) findViewById(R.id.button2);  //�޸�
		Button but3 = (Button) findViewById(R.id.button3);  //���
		Button but4 = (Button) findViewById(R.id.button4);  //��ѯ
		
		
		tv = (TextView) findViewById(R.id.textView3);
		
		//�������ݿ�
		db = SQLiteDatabase.openOrCreateDatabase(this.getFilesDir().toString() + "Answer.db", null);
		
		//����
		but1.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				String tihao = ((EditText) findViewById(R.id.editText1)).getText().toString();
				String daan = ((EditText) findViewById(R.id.editText2)).getText().toString();
				
				//��������
				try{
					
					String searchStr[] = {tihao};
					if(isExist(db.rawQuery("select * from MyAnswer where tihao=?", searchStr),tihao))
					{	db.execSQL("insert into MyAnswer values(null, ?, ?)",
							new String[]{tihao, daan});
					
					OutputData(db.rawQuery("select * from MyAnswer", null));
					}
					else
					{
						//��ʾ10��Ի���    
	    	    		Toast.makeText(Input.this, "������Ѿ����ڣ�����������", 5).show();
					}
				
				}catch(SQLiteException se){
					db.execSQL("create table MyAnswer(" +
							"_id integer primary key autoincrement," +
							"tihao," +
							"daan)");
					db.execSQL("insert into MyAnswer values(null, ?, ?)",
							new String[]{tihao, daan});
					OutputData(db.rawQuery("select * from MyAnswer", null));
				}
			}
        });
		
		//�޸�����
		but2.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				String tihao = ((EditText) findViewById(R.id.editText1)).getText().toString();
				String daan = ((EditText) findViewById(R.id.editText2)).getText().toString();
				
				try{
					String [] updateStr = {daan, tihao};
					db.execSQL("update MyAnswer set daan=? where tihao=?", updateStr);
					OutputData(db.rawQuery("select * from MyAnswer", null));
					}catch(SQLiteException se){
					
				}
				
			}
        });
		
		//���
		but3.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub		
				A=(EditText)findViewById(R.id.editText1);
				B=(EditText)findViewById(R.id.editText2);
				//ɾ����
				try{
					db.execSQL("drop table MyAnswer");
					tv.setText(" ");
					A.setText("");
					B.setText("");
				}catch(SQLiteException se){
					
				}
			}
		});
		
		//��ѯ
		but4.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub						
				try{
					String tihao = ((EditText) findViewById(R.id.editText1)).getText().toString();
					
					String searchStr[] = {tihao};
					
					OutputData(db.rawQuery("select * from MyAnswer where tihao=?", searchStr));
				}catch(SQLiteException se){
					
				}
			}
		});
		
	}
	//�ж�����Ƿ���ڵĺ���
	public boolean isExist(Cursor c,String tihao){
		while(c.moveToNext()){
		String tihao1=c.getString(1);
		if(tihao1.equals(tihao))
		return false;
		}
		return true;
	}
	
	
	//���ı��������Ϣ�ĺ���
	public void OutputData(Cursor c){
		String s = " ";
		//����ΪʲôҪ��while��Ҳ�ǲ������������ѧϰ
		//android�����ݿ⴦��ʹ��cursorʱ���α겻�Ƿ���Ϊ0���±꣬���Ƿ���Ϊ-1���±괦��ʼ�ġ�
		//Ҳ����˵���ظ�cursor��ѯ���ʱ�����ܹ����ϴ�cursor����ȡֵ��
//		��ʹ��android.database.Cursorʱ����getString(int)����ʱ����android.database.CursorIndexOutOfBoundsException: Index -1 requested, with a size of 1
//		���������ԭ����Ӧ���ȵ���cursor.moveToFirst();��
		while(c.moveToNext()){
			int id = c.getInt(0);
			String tihao = c.getString(1);
			String daan = c.getString(2);
			s += (id + " " + tihao + " " + daan + "  ");
		}
		
		tv.setText(s);
	}
	
	public void onDestroy(){
		super.onDestroy();
		//�˳�����ʱ���ر����ݿ�
		if(db != null && db.isOpen()){
			db.close();
		}
	}
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
