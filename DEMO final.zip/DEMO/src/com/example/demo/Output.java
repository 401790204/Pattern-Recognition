package com.example.demo;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Output extends Activity {

	String Aone, Atwo, Athree;
	int count;
	SQLiteDatabase db;
	TextView tv;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_output);
		
		count = 0;  //ͳ�ƴ����Ŀ
		
		tv = (TextView)findViewById(R.id.textView4);
		
		//�����ݿ�
		db = SQLiteDatabase.openOrCreateDatabase(this.getFilesDir().toString() + "Answer.db", null);
		
		Button but = (Button) findViewById(R.id.button1);
		
		but.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Aone = ((EditText) findViewById(R.id.editText1)).getText().toString();
				Atwo = ((EditText) findViewById(R.id.editText2)).getText().toString();
				Athree = ((EditText) findViewById(R.id.editText3)).getText().toString();
				
				sampleAb sa=new sampleAb();
				sa.sample();
				
				try{
					Cursor cursor = db.rawQuery("select * from MyAnswer", null);
					
					cursor.moveToFirst();
					String answerOne = cursor.getString(2);
					int personid = cursor.getInt(0);
					String i=cursor.getString(1);
					Log.i("output", i+"     "+personid);
					
					cursor.moveToNext();
					String answerTwo = cursor.getString(2);
					
					cursor.moveToNext();
					String answerThree = cursor.getString(2);
					String one[] = {"1"};
					String two[] = {"2"};
					String three[] = {"3"};
				
					if(Aone.equals(OutputAnswer(db.rawQuery("select * from MyAnswer where tihao=?", one)))){
						count++;
					}
					if(Atwo.equals(OutputAnswer(db.rawQuery("select * from MyAnswer where tihao=?", two)))){
						count++;
					}
					if(Athree.equals(OutputAnswer(db.rawQuery("select * from MyAnswer where tihao=?", three)))){
						count++;
					}
					
					tv.setText("��ȷ������" + count + "\n" +
							"���Ĵ𰸣�\n" +
							"1 " + Aone + "  2 " + Atwo + "  3 " + Athree+
							"\n ��ȷ�𰸣�\n" +
					"1 " + answerOne + "  2 " + answerTwo + "  3 " + answerThree);
					count=0;
				}catch(SQLiteException se){
					
				}
			}
        });
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public String OutputAnswer(Cursor c){
		String daan = "";
		//����ΪʲôҪ��while��Ҳ�ǲ������������ѧϰ
		while(c.moveToNext()){
			daan = c.getString(2);
		}
		return daan;
	}

}
