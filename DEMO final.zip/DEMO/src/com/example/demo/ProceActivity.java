package com.example.demo;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class ProceActivity extends Activity implements OnClickListener{
	 int[] point;
	private Button btnProc,btntwo,btnone;  
    private ImageView imageView;  
    private Bitmap bmp;
    private String path=Environment.getExternalStorageDirectory()+"xy.jpg";
    FileInputStream in;
    
  //OpenCV�����ز���ʼ���ɹ���Ļص��������ڴ����ǲ������κβ���  
    private BaseLoaderCallback  mLoaderCallback = new BaseLoaderCallback(this) {  
        @Override  
        public void onManagerConnected(int status) {  
            switch (status) {  
                case LoaderCallbackInterface.SUCCESS:{  
                } break;  
                default:{  
                    super.onManagerConnected(status);  
                } break;  
            }  
        }  
    };  
   
    @SuppressLint("SdCardPath") @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //���︴��ճ����ʱ��û�и������棬�������Ա���ָ��
        setContentView(R.layout.activity_proce);
        btnProc = (Button) findViewById(R.id.butchange);  
        btntwo=(Button)findViewById(R.id.buttwo);
        btnone=(Button)findViewById(R.id.butone);
        imageView = (ImageView) findViewById(R.id.image_view); 
        /**
         * Environment.getExternalStorageDirectory()�õ�������mnt/sdcard�� ���ҵ���sd���ĸ�Ŀ¼
         */
        File file = new File("/sdcard/xy.jpg");
        try {
			 in=new FileInputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        //��lenaͼ����س����в�������ʾ  
         bmp = BitmapFactory.decodeStream(in); 
         Bitmap newbitmap = rotaingImageView(90, bmp);
         
         
        imageView.setImageBitmap(newbitmap);  
        Log.i("test", "xiangshi");
        //���ϼ�����
        btnProc.setOnClickListener(this);
        btntwo.setOnClickListener(this);
        btnone.setOnClickListener(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


	@Override
	public void onClick(View arg0) {
		
		  Mat rgbMat = new Mat();  
	        Mat grayMat = new Mat();  
	        //��ȡlena��ɫͼ������Ӧ����������  
	        Utils.bitmapToMat(bmp, rgbMat);  
	       
	        //����ɫͼ������ת��Ϊ�Ҷ�ͼ�����ݲ��洢��grayMat��  
	        Imgproc.cvtColor(rgbMat, grayMat, Imgproc.COLOR_RGB2GRAY);  
	        
	        //����һ���Ҷ�ͼ��  
	        Bitmap agrayBmp = Bitmap.createBitmap(bmp.getWidth(), bmp.getHeight(), Config.RGB_565);  
	        //������grayMatת��Ϊ�Ҷ�ͼ��  
	        Utils.matToBitmap(grayMat, agrayBmp);  
	        double[] db=new double[1];
	        db=grayMat.get(67, 1);
	        for(int i=0;i<1;i++){
	        	Log.i("new world", db[i]+"");
	        }
	        //����һ����ת�Ķ�����������ת��90��
	        Bitmap grayBmp=rotaingImageView(90, agrayBmp); 
	      //��ȡ��ǰ������������
    		Button but=(Button)findViewById(arg0.getId());
    		
    		//�жϵ�ǰ�İ�ť�Ƿ�Ϊ��½��ť
    		if(but.getText().toString().equals("gray process")){
    			imageView.setImageBitmap(grayBmp);
		}
    		if(but.getText().toString().equals("��ֵ��")){
    			Bitmap bit=gray2Binary(grayBmp);
    			
    			
   		       Log.i("x", point[0]+" "+point[1]+" "+point[2]+"  "+point[3]);
    		       
    		       Bitmap bmp2=Bitmap.createBitmap(bit, point[0], point[2], point[1]-point[0], point[3]-point[2]);
    		       int PER=(point[3]-point[2])/10;
    		       for(int k=0;k<10;k++){
    		       Bitmap bmp3=Bitmap.createBitmap(bmp2, (point[1]-point[0])/2+5, k*PER+7,  45, 45);
    		       Log.i("test", k+"");
    		       try      
   	            {      
   	                File file = new File("/sdcard/model"+k+".jpg");      
   	                BufferedOutputStream bos       
   	                = new BufferedOutputStream(new FileOutputStream(file));      
   	                bmp3.compress(Bitmap.CompressFormat.JPEG,100,bos);      
   	                bos.flush();      
   	                bos.close(); 
   	            }catch(Exception e)      
   	            {      
   	                e.printStackTrace();      
   	            }    
    		       
		        imageView.setImageBitmap(bmp3);
    		       }
		       
    		}
    		if(but.getText().toString().equals("ֱ�߼��")){
//    			Bitmap bit=gray2Binary(grayBmp);
//		        imageView.setImageBitmap(bit);	
		        
		        
//		        Mat lines=new Mat();
//		        Matrix matrix = new Matrix();  
//		        matrix.postScale(bit.getWidth(), bit.getHeight());  
//		        Bitmap houghdstBmp = Bitmap.createBitmap(bit , 0, 0, bit.getWidth(), bit.getHeight(), matrix, false);
//		        
//		        Imgproc.HoughLines(matrix, lines, 1.0, Math.PI/180, 100);
	       // Imgproc.h
		        
		        
		        
//		        Mat mYuv = new Mat();
		        Mat mRgba = new Mat(grayBmp.getWidth(), grayBmp.getHeight(), CvType.CV_8UC1);
		        //Imgproc.cvtColor(mYuv, mRgba, Imgproc.COLOR_YUV420sp2RGB, 4);
		        
		        Mat thresholdImage = new Mat(grayBmp.getWidth(), grayBmp.getHeight(), CvType.CV_8UC1);
		        Utils.bitmapToMat(grayBmp, thresholdImage); 
//		        mYuv.pu
		        //mYuv.put(0, 0, data);
//		        Utils.bitmapToMat(bit, mYuv);  
//		        Imgproc.cvtColor(mYuv, mRgba, Imgproc.COLOR_YUV420sp2RGB, 4);
//		        Imgproc.cvtColor(mRgba, thresholdImage, Imgproc.COLOR_RGB2GRAY, 4);
		        Imgproc.Canny(thresholdImage, thresholdImage, 80, 100, 3 , true);
		        
		        
		        Mat lines = new Mat();
		        int threshold = 50;
		        int minLineSize = 50;
		        int lineGap = 20;

		        Imgproc.HoughLinesP(thresholdImage, lines, 1, Math.PI/180, threshold, minLineSize, lineGap);

		        for (int x = 0; x < lines.cols(); x++) 
		        {
		              double[] vec = lines.get(0, x);
		              double x1 = vec[0], 
		                     y1 = vec[1],
		                     x2 = vec[2],
		                     y2 = vec[3];
		              Point start = new Point(x1, y1);
		              Point end = new Point(x2, y2);
		              Core.line(thresholdImage, start, end, new Scalar(225,0,0),2 );

		        }
		        Bitmap bmp = Bitmap.createBitmap(grayBmp.getWidth(), grayBmp.getHeight(), Bitmap.Config.RGB_565);
		        Log.i("where", "jump that function here.......................................");
		        
		        
		        Utils.matToBitmap(thresholdImage, bmp);
		        
		        
		        Log.i("where", "jump that function here");
		       point= findPoint( bmp);
//		       Log.i("x", point[0]+" "+point[1]+" "+point[2]+"  "+point[3]);
		       
		       Bitmap bmp2=Bitmap.createBitmap(bmp, point[0], point[2], point[1]-point[0], point[3]-point[2]);
		        imageView.setImageBitmap(bmp2);	 
		        
		       
		        
		        
		        try      
	            {      
	                File file = new File("/sdcard/xy2.jpg");      
	                BufferedOutputStream bos       
	                = new BufferedOutputStream(new FileOutputStream(file));      
	                bmp.compress(Bitmap.CompressFormat.JPEG,100,bos);      
	                bos.flush();      
	                bos.close(); 
	            }catch(Exception e)      
	            {      
	                e.printStackTrace();      
	            }    
		}
	}
	
	@Override  
    public void onResume(){  
        super.onResume();  
        //ͨ��OpenCV���������ز���ʼ��OpenCV��⣬��νOpenCV���������  
        //OpenCV_2.4.3.2_Manager_2.4_*.apk�������������OpenCV��װ����apkĿ¼��  
        OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_2_4_9, this, mLoaderCallback);  
    }  
	
	// �ú���ʵ�ֶ�ͼ����ж�ֵ������  
    public Bitmap gray2Binary(Bitmap graymap) {  
        //�õ�ͼ�εĿ��Ⱥͳ���  
        int width = graymap.getWidth();  
        int height = graymap.getHeight();  
        //������ֵ��ͼ��  
        Bitmap binarymap = null;  
        binarymap = graymap.copy(Config.ARGB_8888, true);  
        //�õ���ǰ���ص�ֵ  
        int h = binarymap.getPixel(0, 0); 
        int first = (h & 0x000000FF);  
        int max=first,min=first;
        Log.i("first", first+"");
        //����ѭ������ͼ������ؽ��д���  
        for (int i = 0; i < width; i++) {  
            for (int j = 0; j < height; j++) {  
            	  //�õ���ǰ���ص�ֵ  
                int col = binarymap.getPixel(i, j); 
                int blue = (col & 0x000000FF);  
                if(blue>max)max=blue;
                if(blue<min)min=blue;
            }
            }
        Log.i("proce", min+"");
        Log.i("proce", max+"");
        int mid=(max+min)/2;
        int T=computeThreshold(mid,binarymap);
        Log.i("proce", mid+"");
        //����ѭ������ͼ������ؽ��д���  
        for (int i = 0; i < width; i++) {  
            for (int j = 0; j < height; j++) {  
                //�õ���ǰ���ص�ֵ  
                int col = binarymap.getPixel(i, j);  
                //�õ�alphaͨ����ֵ  
             //   int alpha = col & 0xFF000000;  
                //�õ�ͼ�������RGB��ֵ  
              //  int red = (col & 0x00FF0000) >> 16;  
              //  int green = (col & 0x0000FF00) >> 8;  
                //���ﴫ�����ľ��ǻҶȻ����˵�BITMAP
                int blue = (col & 0x000000FF);  
                // �ù�ʽX = 0.3��R+0.59��G+0.11��B�����X����ԭ����RGB  
             //   int gray = (int) ((float) red * 0.3 + (float) green * 0.59 + (float) blue * 0.11);  
                //��ͼ����ж�ֵ������  
                if (blue <= T) {   
                	blue = 0;  
                } else {  
                	blue = 255;  
                }  
             
                // �µ�ARGB  
                int newColor = col | (blue << 16) | (blue << 8) | blue;  
                //������ͼ��ĵ�ǰ����ֵ  
                binarymap.setPixel(i, j, newColor);  
            }  
        }  
        
      
        return binarymap;  
    }  
    
    
   /*
    * ��תͼƬ 
    * @param angle 
    * @param bitmap 
    * @return Bitmap 
    */ 
   public static Bitmap rotaingImageView(int angle , Bitmap bitmap) {  
       //��תͼƬ ����   
       Matrix matrix = new Matrix();;  
       matrix.postRotate(angle);  
       System.out.println("angle2=" + angle);  
       // �����µ�ͼƬ   
       Bitmap resizedBitmap = Bitmap.createBitmap(bitmap, 0, 0,  
               bitmap.getWidth(), bitmap.getHeight(), matrix, true);  
       return resizedBitmap;  
   }
   
   public int computeThreshold(int first, Bitmap binarymap){
	   int bigCount = 0, smallCount = 0;
	   int bigSum = 0, smallSum = 0;
	 //����ѭ������ͼ������ؽ��д���  
       for (int i = 0; i < binarymap.getWidth(); i++) {  
           for (int j = 0; j < binarymap.getHeight(); j++) {  
               //�õ���ǰ���ص�ֵ  
               int col = binarymap.getPixel(i, j);  
               int blue = (col & 0x000000FF);  
               if(blue >= first){
            	   bigCount++;
            	   bigSum += blue;
               }else{
            	   smallCount++;
            	   smallSum += blue;
               }
           }  
       } 
       int second = (int)((bigSum/bigCount + smallSum/smallCount)/2);
       //�����Ƕ���������ֵ�Ĳ�ֵ��������ǰ�󱳾��Ĺ�ϵ
       if((second - first) > 35){
    	   second = computeThreshold(second, binarymap);
       }
    return second;
   }
   
   public int[] findPoint(Bitmap bmp){
	   int R=0,P=0,R1=0,P1=0;
	   int pointXY[]=new int[4];//0,1,2,3�ֱ����x��y����С���ֵ
	   for(int i=0;i<bmp.getWidth();i++){
	
		   for(int j=0;j<bmp.getHeight();j++){
			 //�õ���ǰ���ص�ֵ  
               int col = bmp.getPixel(i, j);  
               int blue = (col & 0x000000FF);
               if(blue!=0)
               //����ĵİ�ɫ��231����ɫ��0 
            	   R++;
		   }
		   Log.i("R", R+"");
		   float T= R/bmp.getWidth();
		  
		   if(T>0.6){
			   if(pointXY[0]==0)
			   pointXY[0]=i;
			   
		   }
			 
	   }
	   
	   for(int i=(bmp.getWidth()-1);i>0;i--){
			
		   for(int j=bmp.getHeight();j>0;j--){
			 //�õ���ǰ���ص�ֵ  
               int col = bmp.getPixel(i-1, j-1);  
               int blue = (col & 0x000000FF);
               if(blue!=0)
               //����ĵİ�ɫ��231����ɫ��0 
            	   R1++;
		   }
		   float T= R1/bmp.getWidth();
		  
		   if(T>0.6){
			   if(pointXY[1]==0)
			   pointXY[1]=i;
		   }
			 
	   }
for(int i=0;i<bmp.getHeight();i++){
		   
		   for(int j=0;j<bmp.getWidth();j++){
			 //�õ���ǰ���ص�ֵ  
               int col = bmp.getPixel(j, i);  
               int blue = (col & 0x000000FF);
               if(blue!=0)
               //����ĵİ�ɫ��231����ɫ��0 
            	   P++;
		   }
		   float T= P/bmp.getHeight();
		  
		   if(T>0.3){
			   if(pointXY[2]==0)
			   pointXY[2]=i;
		   }
	   }

for(int i=(bmp.getHeight()-1);i>0;i--){
	   
	   for(int j=bmp.getWidth();j>0;j--){
		 //�õ���ǰ���ص�ֵ  
        int col = bmp.getPixel(j-1, i-1);  
        int blue = (col & 0x000000FF);
        if(blue!=0)
        //����ĵİ�ɫ��231����ɫ��0 
     	   P1++;
	   }
	   float T= P1/bmp.getHeight();
	  
	   if(T>0.3){
		   if(pointXY[3]==0)
		   pointXY[3]=i;
	   }
}
	   
	return pointXY;
	   
   }
   

   
	private void delay(int ms){  
        try {  
            Thread.currentThread();  
            Thread.sleep(ms);  
        } catch (InterruptedException e) {  
            e.printStackTrace();  
        }   
     }  
}
