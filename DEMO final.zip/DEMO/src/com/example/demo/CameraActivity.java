package com.example.demo;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Toast;

public class CameraActivity extends Activity implements  OnClickListener{

	//���ñ���
	MySurfaceView mySurface;
	boolean isClicked = false; 
	public SeekBar sb;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_camera);
		mySurface =(MySurfaceView)this.findViewById(R.id.mySurfaceView2);
//        setContentView(mySurface);
        mySurface.setOnClickListener(this); 
        
         sb=(SeekBar)this.findViewById(R.id.seekBar1);
        
        sb.setOnSeekBarChangeListener(seekListener);
	}

	
	public void onClick(View v) {      
        // TODO Auto-generated method stub      
        if(!isClicked)      
        {      
            mySurface.tackPicture();      
            isClicked = true;  
          //��ʾ10��Ի���    
    		Toast.makeText(CameraActivity.this, "���ճɹ�", 3).show();
    		//ʵ����Intent��Ķ���
    		Intent intent=new Intent();
    		//���ô�LoginActivity��ת��DrawActivityҳ��
    		intent.setClass(CameraActivity.this, ProceActivity.class);
    		delay(1000);
    		//����Activity����ת������Intent�����ý�����ת
    		CameraActivity.this.startActivity(intent);
    		Log.i("test", "camera intent");
        }else      
        {      
            mySurface.voerTack();      
            isClicked = false;      
                  
        }     
    }
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.camera, menu);
		return true;
	}
	
	//��д�˵����¼���������
	public boolean onMenuItemSelected(int feratureID,MenuItem item){
		
		
		//��ȡitem��id
		switch(item.getItemId()){
		case R.id.Zoom:
			int maxZoom = mySurface.getParameters().getMaxZoom();
			sb.setMax(maxZoom);
			//parameters.setZoom(maxZoom);//zoomֵΪ0-maxZoom֮�� �������ý����
			//��ʾ10��Ի���    
    		Toast.makeText(CameraActivity.this, maxZoom+"", 3).show();
    		
			break;
		}
		return true;
	}
	
	private void delay(int ms){  
        try {  
            Thread.currentThread();  
            Thread.sleep(ms);  
        } catch (InterruptedException e) {  
            e.printStackTrace();  
        }   
     }  
	
	private OnSeekBarChangeListener seekListener = new OnSeekBarChangeListener(){
		
		
	        @Override
		         public void onStopTrackingTouch(SeekBar seekBar) {
		         }
		 
		         @Override
		         public void onStartTrackingTouch(SeekBar seekBar) {
		         }
		 
		         @Override
		         public void onProgressChanged(SeekBar seekBar, int progress,
		                 boolean fromUser) {
		        	 Log.i("ZOOM", progress+"");
	        	 mySurface.getParameters().setZoom(progress);
	        	 mySurface.getMyCamera().setParameters(mySurface.getParameters());
		         }
		     };
	 
}
