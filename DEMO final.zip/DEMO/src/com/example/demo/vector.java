package com.example.demo;

public class vector {
	int[] attributes=new int[13];  //13��������vector
	int classlabel;          //���Ա�ǩ A(1) B(2) C(3) D(4)
	public int[] getAttributes() {
		return attributes;
	}
	public void setAttributes(int[] attributes) {
		this.attributes = attributes;
	}
	public int getClasslabel() {
		return classlabel;
	}
	public void setClasslabel(int classlabel) {
		this.classlabel = classlabel;
	}
	//��дһ�¹��췽��
	
	public  vector(){
		
	}
	public  vector(int[] i){
		this.setAttributes(i);
	}
	
}
