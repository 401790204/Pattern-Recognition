package com.example.demo;


import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Camera;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.hardware.Camera.Size;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

public class MySurfaceView extends SurfaceView implements SurfaceHolder.Callback{

	SurfaceHolder holder;// ���ڿ���SurfaceView
	Camera myCamera;
	private Canvas mCanvas; // ����һ�Ż���
	 
    public Camera getMyCamera() {
		return myCamera;
	}

	public void setMyCamera(Camera myCamera) {
		this.myCamera = myCamera;
	}

	private Paint p; // ����һ֧����

    private int r = 20; // Բ������Ͱ뾶
    Camera.Parameters  parameters;
	
	public Camera.Parameters getParameters() {
		return parameters;
	}

	public void setParameters(Camera.Parameters parameters) {
		this.parameters = parameters;
	}

	private PictureCallback jpeg = new PictureCallback() {      
        
        @Override      
        public void onPictureTaken(byte[] data, Camera camera) {      
            // TODO Auto-generated method stub      
            try      
            {      
                Bitmap bm = BitmapFactory.decodeByteArray(data, 0, data.length);      
                File file = new File("/sdcard/xy.jpg");      
                BufferedOutputStream bos       
                = new BufferedOutputStream(new FileOutputStream(file));      
                bm.compress(Bitmap.CompressFormat.JPEG,100,bos);      
                bos.flush();      
                bos.close(); 
                Log.i("test", "save");
            }catch(Exception e)      
            {      
                e.printStackTrace();      
            }      
        }      
    };      
	@SuppressWarnings("deprecation")
	public MySurfaceView(Context context) {
		super(context);
		holder=getHolder();//��ȡsurfaceHolder����
		holder.addCallback(this);
		holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);//��������
		
//		p = new Paint(); // ����һ�����ʶ���
//        p.setColor(Color.RED); // ���û��ʵ���ɫΪ��ɫ
  
	}
	
	//�����������췽����ö�����
		public MySurfaceView(Context context, AttributeSet attrs) {
			super(context, attrs , 0);
			holder=getHolder();//��ȡsurfaceHolder����
			holder.addCallback(this);
			holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);//��������
		}
		
		public MySurfaceView(Context context, AttributeSet attrs, int defStyle) {
			super(context, attrs, defStyle);
			holder=getHolder();//��ȡsurfaceHolder����
			holder.addCallback(this);
			holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);//��������
		}

	public void tackPicture()      
    {      
		 /* ����Camera.Parameters���� */
//			Camera.Parameters  parameters=myCamera.getParameters();
	//	this.setPictureSize(parameters);   
		parameters.setPictureSize(640, 480);
		myCamera.setParameters(parameters);
        myCamera.takePicture(null,null,jpeg);      
    }      
    public void voerTack()      
    {      
        myCamera.startPreview();      
    }      
    
	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
		myCamera.startPreview();
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		
		if(myCamera==null){
			myCamera=Camera.open();//������������ܷ��ڹ��캯���У���Ȼ������ʾ����
			parameters=myCamera.getParameters();
			try{
				myCamera.setDisplayOrientation(90);
				myCamera.setPreviewDisplay(holder);
//				parameters.setFlashMode(Parameters.FLASH_MODE_TORCH);//����
//				myCamera.setParameters(parameters);
			}catch(IOException e){
			e.printStackTrace();	
			}
		}
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder arg0) {
		parameters.setFlashMode(Parameters.FLASH_MODE_OFF);
		myCamera.setParameters(parameters);
		myCamera.stopPreview();//ֹͣԤ��
		myCamera.release();//�ͷ������Դ
		myCamera=null;
		Log.d("ddd","4");
	}
	
	
	public void capture(View source){
		if(myCamera!=null){
			//��������ͷ�Զ��Խ��������
			myCamera.autoFocus(autoFocusCallback);
		}
	}
	AutoFocusCallback autoFocusCallback=new AutoFocusCallback(){
		//���Զ��Խ�ʱ�����÷���
		public void onAutoFocus(boolean success,Camera camera){
			if(success)
			{
				myCamera.takePicture(new ShutterCallback(){
					public void onShutter(){
						//���¿���˲���ִ�д˴�����
					}
				}, new PictureCallback(){

					@Override
					public void onPictureTaken(byte[] arg0, Camera arg1) {
						// TODO Auto-generated method stub
					}
					
				}, jpeg);
			}
		}
	};
	
	private void setPictureSize(Parameters parameters) {
		        List<Size> sizes = parameters.getSupportedPictureSizes();
		         if (sizes == null) {
		            return;
	        }
		         int maxSize = 0;
		         int width = 0;
		         int height = 0;
		         for (int i = 0; i < sizes.size(); i++) {
		             Size size = sizes.get(i);
		             int pix = size.width * size.height;
		             if (pix > maxSize) {
		                 maxSize = pix;
		                 width = size.width;
		                 height = size.height;
		             }
		         }
		         Log.i("tag", "ͼƬ�Ĵ�С��" + width + " height:" + height);
		         parameters.setPictureSize(width, height);
		     }
	
	/**
     * �Զ���һ���������ڻ����ϻ�һ��Բ
     */
    public void Draw() {
        mCanvas = holder.lockCanvas(); // ��û������󣬿�ʼ�Ի�������
        mCanvas.drawCircle(0, 0, r, p); // ��һ��Բ
        holder.unlockCanvasAndPost(mCanvas); // ��ɻ������ѻ�����ʾ����Ļ��
    }

    
    
}

