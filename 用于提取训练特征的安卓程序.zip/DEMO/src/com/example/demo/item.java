package com.example.demo;

public class item {
	public double distance;
	public int classlabel;
	
	
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	public int getClasslabel() {
		return classlabel;
	}
	public void setClasslabel(int classlabel) {
		this.classlabel = classlabel;
	}

}
