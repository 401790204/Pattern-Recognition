package com.example.demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;



import android.annotation.SuppressLint;
import android.util.Log;

public class Classify {

	public FileInputStream in;
	public int MAXSZ=170,NATTRS= 13,K =5; //ѵ�����������ߴ�
	double MAXVALUE= 10000;
	//#define NATTRS 13 //������ 13������
//	#define MAXVALUE 10000	//�������10000
//	#define K 5 
	
	 item[] knn;//ȫ�ֱ�����K-���ڽ�����
	int curTSize = 0; //��ǰѵ�������ĳߴ�
	 vector[] trSet=new vector[MAXSZ];//ȫ�ֱ���  ѵ������
	 
	
	 
	 double Distance( vector v1,  vector v2)
	 {
	 	double d = 0.0;
	 	double tem = 0.0;
	 	for (int i = 0; i < NATTRS; i++)
	 		tem += (v1.attributes[i] - v2.attributes[i])*(v1.attributes[i] - v2.attributes[i]);
	 	d = Math.sqrt(tem);
	 	return d;
	 }
	 
	 int max( item knn[]) //����ֵΪ��Ŀ���������
	 {
	 	int maxNo = 0;
	 	if (K > 1)	for (int i = 1; i < K; i++)
	 	if (knn[i].distance>knn[maxNo].distance)		maxNo = i;
	 	return maxNo;
	 }
	 
	 public  boolean AddtoTSet(vector v)
	 {
		 
	 	if (curTSize >= MAXSZ)
	 	{
	 		Log.i("warning", "��ʾ����ѵ�������ķ�Χ");//��ʾ����ѵ�������ķ�Χ
	 		return false;
	 	}
	 	trSet[curTSize] = v; //��vector�Ž�ѵ��������
	 	curTSize++;
	 	return true;
	 }

	 public int Classify2(vector v)//�����ֵ���һ����
	 {
//		 Log.i("stop", "4");
//		 Log.i("vvvvvv", v.attributes[0]+"");
	 	double dd = 0;
	 	int maxn = 0;
	 	int[] freq=new int[K];
	 	int  mfreqC = 0;//������ִ���
	 	int i;
	 	knn=new item[5];
	 	knn[0]=new item();
	 	knn[1]=new item();
	 	knn[2]=new item();
	 	knn[3]=new item();
	 	knn[4]=new item();
	 	for (i = 0; i < K; i++)	{
	 		knn[i].setDistance(MAXVALUE);}
//	 	 Log.i("stop", "5");
//	 	 Log.i("knn", knn[4].getDistance()+"");
	 	for (i = 0; i < curTSize; i++)
	 	{
	 		dd = Distance(trSet[i], v);
//	 		Log.i("dd", dd+" "+trSet[i].getClasslabel());
	 		maxn = max(knn);//Ϊ�¼����ݸ���ѵ����
	 		if (dd < knn[maxn].distance)
	 		{
	 			knn[maxn].distance = dd;
	 		
	 			knn[maxn].classlabel = trSet[i].classlabel;
	 			
	 		}
	 	}
	 	for (i = 0; i < K; i++){
	 		Log.i("six", knn[i].getClasslabel()+"");
	 	}
	 	for (i = 0; i < K; i++)//freq[i]��ʾknn[i].classlabel���ֵĴ���
	 		freq[i] = 1;
	 	for (i = 0; i < K; i++)
	 	{
	 	for (int j = 0; j < K; j++)
	 	{
	 		if(knn[i]!=null&&knn[j]!=null){
	 	if ((i != j) && (knn[i].classlabel == knn[j].classlabel))	freq[i] += 1;}
	 	}
	 	}
	 	int mfreq = 1;
//	 	Log.i("knn0", knn[1].classlabel+"");
	 	mfreqC = knn[0].classlabel;
	 	for ( i = 0; i < K; i++)
	 	if (freq[i] > mfreq)
	 	{
	 		mfreq = freq[i];//�������������
	 		mfreqC = knn[i].classlabel;
	 	}
//	 	Log.i("output1", mfreqC+"");
	 	return mfreqC;
	 }

	 
	 @SuppressLint("SdCardPath") public int outPut(int[] KKK) 
	 {
			int classlabel,c, n;//���Ի���int
	//ʵ����trSet����
		for(int u=0;u<MAXSZ;u++){
			trSet[u]=new vector();
		}
	 	//std::cout << "�ɼ���ѵ������������ʾ��"<<"\n"<<endl;
	 	/*����ѵ������*/
	 	
	 	int i = 0;
	 	String lineTxt;
	 	  File file = new File("/sdcard/sampleDATA.txt");
	        try {
				 in=new FileInputStream(file);
				  getString(in);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	        
//	 	ifstream filein("D:\\��������.txt");
//	 	if (in.equals(null))
//	 	{
//////	 		cout << "Can't open 1.txt" << endl;
//	 		return;
//	 	}
//	 	while (in.has) //����ɼ�����������
//	 	{
//	 		 c=in.read();
////	 		filein >> c;
//	 		trExmp.classlabel = c;
////	 		cout << trExmp.classlabel << " ";
//	 		for (int i1 = 0; i1 < NATTRS; i1++)
//	 		{
////	 			filein >> n;
//	 			n=in.read();
//	 			trExmp.attributes[i] = n;
////	 			cout << trExmp.attributes[i] << " " ;
//	 		}
////	 		cout <<endl;
//	 		if (!AddtoTSet(trExmp))		break;
//	 	}
//	 	in.close();
	 	/*�����������*/
//	 	Log.i("stop", "2");
//	 	int[] O1=new int[]{1477 ,216, 121, 173, 142, 121, 249, 253, 202 ,32, 34, 40, 32};
//	 	int[] O=new int[]{ 1531, 242 ,220 ,158, 174 ,181, 122 ,158 ,276 ,36 ,36, 36 ,36 };
	// 	vector testv = new vector(){ 1531, 242 ,220 ,158, 174 ,181, 122 ,158 ,276 ,36 ,36, 36 ,36 };
	// 	testv=	{ 1531, 242 ,220 ,158, 174 ,181, 122 ,158 ,276 ,36 ,36, 36 ,36 };
//	 	 vector testv = { { 1531, 242 ,220 ,158, 174 ,181, 122 ,158 ,276 ,36 ,36, 36 ,36 }, 13 };
	 	vector testv=new vector(KKK);
	 	testv.setClasslabel(13);
//	 	Log.i("stop", "3");
	 	classlabel = Classify2(testv);
//	 	cout << "�����������,�ó����Ϊ: ";
//	 	cout << classlabel << endl;
	 //	for (i = 0; i < K; i++)	cout << knn[i].classlabel << "	����Ϊ:" << knn[i].distance << "\t" << endl;
	 	//AddtoTSet();
	 	
//	 	Log.i("ABCD", classlabel+"");
	 	return classlabel;
	  }
	
	 public  void getString(InputStream inputStream) {  
		   
		 	int classlabel,c, n;//���Ի���int
		    InputStreamReader inputStreamReader = null;  
		    try {  
		        inputStreamReader = new InputStreamReader(inputStream, "gbk");  
		    } catch (UnsupportedEncodingException e1) {  
		        e1.printStackTrace();  
		    }  
		    BufferedReader reader = new BufferedReader(inputStreamReader);  
		    StringBuffer sb = new StringBuffer("");  
		    String line;  
		    try {  
		        while ((line = reader.readLine()) != null) { 
		        	vector trExmp = new vector();
		            String ss[]=line.split(" ");
		            trExmp.classlabel=Integer.parseInt(ss[0]);
		            
		            for (int i1 = 0; i1 < 13; i1++)
		    	 		{
		            	trExmp.attributes[i1]=Integer.parseInt(ss[i1+1]);
//		            	Log.i("666",trExmp.attributes[i1]+"");
		        }
		            AddtoTSet(trExmp);
		        }  
		    } catch (IOException e) {  
		        e.printStackTrace();  
		    }  
		} 

}
