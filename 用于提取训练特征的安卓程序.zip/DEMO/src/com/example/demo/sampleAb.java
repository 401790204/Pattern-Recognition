package com.example.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;

import org.opencv.android.Utils;
import org.opencv.core.Mat;
import org.opencv.core.Rect;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.util.Log;

public class sampleAb {

	
	double PI= 3.1415926;
	int[] fangxiang=new int[4];
	FileInputStream in;
	
	int max(int[] a)
	{
		int temp;
		temp = a[0];
		for (int i = 1; i<4; i++)
		{
			if (a[i]>temp)
				temp = a[i];
		}
		return temp;
	}
	
	int min(int[] b)
	{
		int temp2;
		temp2 = b[0];
		for (int i = 1; i<4; i++)
		{
			if (b[i]<temp2)
				temp2 = b[i];
		}
		return temp2;
	}

	//�ƽ���������
	public int[] close(Mat result)
	{
		char flag = 0;

		for (int i = 0; i < result.width(); i++)
		{
			for (int j = 0; j < result.height(); j++)
			{
				char intensity = (char)result.get(j, i)[0];
				if (intensity == 255)
				{
					fangxiang[0] = i;
//					std::cout << " zuo " << zuo << std::endl;
					flag = 1;
					break;
				}
			}
			if (flag == 1)
			{
				flag = 0;
				break;
			}
		}
		for (int i = result.width() - 1; i > 0; i--)
		{
			for (int j = 0; j < result.height(); j++)
			{
				char intensity = (char)result.get(j, i)[0];
				if (intensity == 255)
				{
					fangxiang[1] = i;
//					std::cout << " you " << you << std::endl;
					flag = 1;
					break;
				}
			}
			if (flag == 1)
			{
				flag = 0;
				break;
			}
		}
		for (int i = 0; i < result.height(); i++)
		{
			for (int j = 0; j < result.width(); j++)
			{
				char intensity = (char)result.get(i, j)[0];
				if (intensity == 255)
				{
					fangxiang[2] = i;
//					std::cout << " shang " << shang << std::endl;
					flag = 1;
					break;
				}
			}
			if (flag == 1)
			{
				flag = 0;
				break;
			}
		}
		for (int i = result.height() - 1; i > 0; i--)
		{
			for (int j = 0; j < result.width(); j++)
			{
				char intensity = (char)result.get(i, j)[0];
				if (intensity == 255)
				{
					fangxiang[3] = i;
//					std::cout << " xia " << xia << std::endl;
					flag = 1;
					break;
				}
			}
			if (flag == 1)
			{
				flag = 0;
				break;
			}
		}
		return fangxiang;
	}
	
	
	public int ostu(Mat image)
	{
		 //����ɫͼ������ת��Ϊ�Ҷ�ͼ�����ݲ��洢��grayMat��  
		 Imgproc.cvtColor(image.clone(), image, Imgproc.COLOR_RGB2GRAY);
		int width = image.width();
		int height = image.height();
//		int x = 0, y = 0;
		float ip1, ip2, is1, is2, w0, w1, mean1, mean2, mean, deltaTmp, deltaMax;
		int[]  pixelCount=new int[256];
		int i, j, pixelSum = width * height, thres = 0;
		for (i = 0; i < 256; i++)
		{
			pixelCount[i] = 0;
		}
		int pixel = 0;
		for (i = 0; i < height; i++)
		{
			for (j = 0; j <width; j++)
			{
				pixel = (int)image.get(i, j)[0];
				
				pixelCount[pixel]++;

			}
		}
		//����ostu�㷨,�õ�ǰ���ͱ����ķָ�
		//�����Ҷȼ�[0,255],������������ĻҶ�ֵ,Ϊ�����ֵ
		deltaMax = 0;
		for (i = 0; i < 256; i++)
		{
			ip1 = ip2 = is1 = is2 = w0 = w1 = mean1 = mean2 = mean = deltaTmp = 0;
			for (j = 0; j < 256; j++)
			{
				if (j <= i) //��������
				{
					ip1 += pixelCount[j] * j;
					is1 += pixelCount[j];
				}

				else
				{
					ip2 += pixelCount[j] * j;
					is2 += pixelCount[j];
				}

			}

			mean1 = ip1 / is1;     //��һ������ƽ���Ҷ�ֵ
			w0 = (float)is1 / (float)pixelSum;//��һ������ռ����ͼ�����
			mean2 = ip2 / is2;
			w1 = 1 - w0;
			mean = w0*mean1 + w1*mean2;
			deltaTmp = w0*w1*(mean1 - mean2)*(mean1 - mean2);//�Ҷ�ֵΪi����ֵ����䷽��
			if (deltaTmp>deltaMax)
			{
				deltaMax = deltaTmp;
				thres = i;
			}
		}
		return thres;

	}
	
	public String sample(int k)
	{
//		Mat image=new Mat();
//		Mat image1=new Mat();
//		Mat imagegray=new Mat();
//		Mat image_gray1=new Mat();

		int threhold_value;
//		int[] ALL=new int[]{ 0, 0, 0, 0, 0, 0, 0, 0 };
//		int MAX = 0, MIN = 0;
//		double[]  ALL_Sym=new double[]{0,0,0,0};
		//����ͼƬ����
		  File file = new File("/sdcard/model"+k+".jpg");
	        try {
				 in=new FileInputStream(file);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//	        Log.i("kkkkkkkkkkkkkk", k+"");
	        //��lenaͼ����س����в�������ʾ  
	        Bitmap bmp = BitmapFactory.decodeStream(in); 
	        
	        Mat rgbMat = new Mat();  
	        Mat grayMat = new Mat();  
	        
	      //��ȡlena��ɫͼ������Ӧ����������  
	        Utils.bitmapToMat(bmp, rgbMat);  
	       
	        //����ɫͼ������ת��Ϊ�Ҷ�ͼ�����ݲ��洢��grayMat��  
	        Imgproc.cvtColor(rgbMat, grayMat, Imgproc.COLOR_RGB2GRAY);  
	        
	      //����һ���Ҷ�ͼ��  
	        Bitmap agrayBmp = Bitmap.createBitmap(bmp.getWidth(), bmp.getHeight(), Config.RGB_565);  
	        //������grayMatת��Ϊ�Ҷ�ͼ��  
	        Utils.matToBitmap(grayMat, agrayBmp);  
	        
	        
//		image = imread("D:\\��������-panqi\\A.jpg"); 
//		if (!image.data) 
//			return 0;  
		/*����������*/
		Mat element = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(5,5));
//				getStructuringElement(MORPH_RECT, Size(5, 5));  
		 Imgproc.morphologyEx(rgbMat, rgbMat, Imgproc.MORPH_OPEN, element);
		/*��ֵ����*/
		threhold_value=ostu(rgbMat);
		Imgproc.threshold(rgbMat, grayMat, threhold_value, 255, Imgproc.THRESH_BINARY_INV);
		//vɾ����ֵͼ��BW�����С��P�Ķ��� ȥ�����
//		bwareaopen(image_gray,100);
//		Imgproc.cvtColor(image_gray, image_gray, Imgproc.COLOR_RGB2GRAY);
		/*ϸ������*/
		Mat image_thin=grayMat.clone();
//		Log.i("xi", "555");
		gThin thin_pro=new gThin();
//		thin_pro.cvHilditchThin(grayMat, image_thin);
//		Log.i("xi", "666");
		/*�ƽ�����*/
		Mat result = image_thin.clone();
		close(result);
		Rect rect1=new Rect(fangxiang[0],fangxiang[2],fangxiang[1]-fangxiang[0],fangxiang[3]-fangxiang[2]);
		//��һ���������
		Mat image_roi = result.submat(rect1);
		Imgproc.resize(image_roi, image_roi, new Size(45, 45));
//		resize(image_roi, image_roi,cv::Size(45, 45));
		/*13����������*/
		int summ=0,summ1=0,summ2=0,summ3=0,summ4=0,summ5=0,summ6=0,summ7=0,summ8=0;
		summ = Sum_Block(image_roi, 0, image_roi.height(), 0, image_roi.width());
//		put("������ " , summ);
//		int sum_one = (int)(image_roi.width() *image_roi.height() / 8);
//		put( "ÿС������",sum_one);
		summ1 = Sum_Block(image_roi, 0, image_roi.height() / 4, 0, image_roi.width() / 2);
//		put( "��1�����ر��� ",summ1 );
		summ2 = Sum_Block(image_roi, image_roi.height() / 4, image_roi.height() / 2, 0, image_roi.width() / 2);
//		put( "��2�����ر��� ",summ2);
		summ3 = Sum_Block(image_roi, image_roi.height() / 2, 3 * image_roi.height() / 4, 0, image_roi.width() / 2);
//		put("��3�����ر��� " ,summ3);
		summ4 = Sum_Block(image_roi, 3 * image_roi.height() / 4, image_roi.height(), 0, image_roi.width() / 2);
//		put("��4�����ر���",summ4);
		summ5 = Sum_Block(image_roi, 0, image_roi.height() / 4, image_roi.width() / 2, image_roi.width());
//		put("��1�����ر��� ",summ5);
		summ6 = Sum_Block(image_roi, image_roi.height() / 4, image_roi.height() / 2, image_roi.width() / 2, image_roi.width());
//		put("��2�����ر��� ",summ6);
		summ7 = Sum_Block(image_roi, image_roi.height() / 2, 3 * image_roi.height() / 4, image_roi.width() / 2, image_roi.width());
//		put("��3�����ر��� ",summ7);
		summ8 = Sum_Block(image_roi, 3 * image_roi.height() / 4, image_roi.height(), image_roi.width() / 2, image_roi.width());
//		put("��4�����ر��� ",summ8);

		int scan_col_1 = 0, scan_col_2 = 0, scan_row_1=0, scan_row_2=0;
		for (int i = 0; i < image_roi.height(); i++)
		{
			char intensity = (char)image_roi.get(i, image_roi.width() / 4)[0];
			if (intensity==0)
			{
				scan_col_1++;
			}
		}
		for (int i = 0; i < image_roi.height(); i++)
		{
			char intensity =(char) image_roi.get(i, 3 * image_roi.width() / 4)[0];
			if (intensity==0)
			{
				scan_col_2++;
			}
		}
		for (int j = 0; j < image_roi.width(); j++)
		{
			char intensity = (char)image_roi.get(3 * image_roi.height() / 4, j)[0];
			if (intensity==0)
			{
				scan_row_1++;
			}
		}
		for (int j = 0; j < image_roi.width(); j++)
		{
			char intensity = (char)image_roi.get(image_roi.height() / 4, j)[0];
			if (intensity==0)
			{
				scan_row_2++;
			}
		}
//		std::cout << "�м����� ��һ�����ظ��� " << scan_col_1 << std::endl;
//		std::cout << "�м����� �ڶ������ظ��� " << scan_col_2 << std::endl;
//		std::cout << "�м����� ��һ�����ظ��� " << scan_row_1 << std::endl;
//		std::cout << "�м����� �ڶ������ظ��� " << scan_row_2 << std::endl;

		int[] symbol=new int[13] ;
		symbol[0] = summ;
		symbol[1] = summ1;
		symbol[2] = summ2;
		symbol[3] = summ3;
		symbol[4] = summ4;
		symbol[5] = summ5;
		symbol[6] = summ6;
		symbol[7] = summ7;
		symbol[8] = summ8;
		symbol[9] = scan_col_1;
		symbol[10] = scan_col_2;
		symbol[11] = scan_row_1;
		symbol[12] = scan_row_2;
		String str="";
		for(int i=0;i<13;i++){
		Log.i("win", symbol[i]+"");
		str=str+symbol[i]+" ";
		}
		
	
		return str;
//		for (int i = 0; i < (sizeof(symbol) / sizeof(int)); i++)
//		{
//			cout << symbol[i] << " ";
//		}
//		/*�������ֵ���ı��ĵ�*/
//		ofstream fout("d:\\output.txt");
//		for (int i = 0; i < (sizeof(symbol) / sizeof(int)); i++)
//		{
//			fout << symbol[i] << " ";
//		}
//		fout << flush; 
//		fout.close();
//		cv::waitKey();
//		return 0;
	}
	
	int Sum_Block(Mat image_org, int ROW_START, int ROW_END, int COL_START, int COL_END)
	{
		int sum = 0;
		for (int i = ROW_START; i <ROW_END; i++)
		{
			for (int j = COL_START; j < COL_END; j++)
			{
				char intensity = (char)image_org.get(i, j)[0];
				if (intensity == 0)
				{
					sum++;
				}
			}
		}
		return sum;
	}


}
